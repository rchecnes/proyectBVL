``odd``
=======

``odd`` returns ``true`` if the given number is odd:

.. code-block:: jinja

    {{ var is odd }}

.. seealso:: :doc:`even<../tests/even>`
